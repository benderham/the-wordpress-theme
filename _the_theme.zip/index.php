<?php
//silence! most sites don't need this cause we have other templates that take precedence
//only use if not gonna get messy!
?>